const express = require('express')
const { Patrol, Company, Project, Personnel } = require('../models')
const { authMiddleware } = require('../middleware/auth')

const router = express.Router()

// Get all patrols
router.get('/', authMiddleware, async (req, res) => {
  try {
    const { companyId, projectId, status } = req.query
    const where = {}
    
    if (companyId) where.companyId = companyId
    if (projectId) where.projectId = projectId
    if (status) where.status = status

    const patrols = await Patrol.findAll({
      where,
      include: [
        { model: Company, as: 'company', attributes: ['id', 'name'] },
        { model: Project, as: 'project', attributes: ['id', 'name'] },
        { model: Personnel, as: 'assignee', attributes: ['id', 'name'] }
      ],
      order: [['createdAt', 'DESC']]
    })

    res.json(patrols.map(p => ({
      ...p.toJSON(),
      company: p.company?.name || '',
      assignee: p.assignee?.name || '',
      time: p.timeRange
    })))
  } catch (error) {
    console.error('Get patrols error:', error)
    res.status(500).json({ message: 'Devriyeler alınırken hata oluştu' })
  }
})

// Get patrol by ID
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const patrol = await Patrol.findByPk(req.params.id, {
      include: [
        { model: Company, as: 'company' },
        { model: Project, as: 'project' },
        { model: Personnel, as: 'assignee' }
      ]
    })

    if (!patrol) {
      return res.status(404).json({ message: 'Devriye bulunamadı' })
    }

    res.json(patrol)
  } catch (error) {
    console.error('Get patrol error:', error)
    res.status(500).json({ message: 'Devriye alınırken hata oluştu' })
  }
})

// Create patrol
router.post('/', authMiddleware, async (req, res) => {
  try {
    const patrol = await Patrol.create(req.body)
    res.status(201).json(patrol)
  } catch (error) {
    console.error('Create patrol error:', error)
    res.status(500).json({ message: 'Devriye oluşturulurken hata oluştu' })
  }
})

// Update patrol
router.put('/:id', authMiddleware, async (req, res) => {
  try {
    const patrol = await Patrol.findByPk(req.params.id)

    if (!patrol) {
      return res.status(404).json({ message: 'Devriye bulunamadı' })
    }

    await patrol.update(req.body)
    res.json(patrol)
  } catch (error) {
    console.error('Update patrol error:', error)
    res.status(500).json({ message: 'Devriye güncellenirken hata oluştu' })
  }
})

// Delete patrol
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const patrol = await Patrol.findByPk(req.params.id)

    if (!patrol) {
      return res.status(404).json({ message: 'Devriye bulunamadı' })
    }

    await patrol.destroy()
    res.json({ message: 'Devriye silindi' })
  } catch (error) {
    console.error('Delete patrol error:', error)
    res.status(500).json({ message: 'Devriye silinirken hata oluştu' })
  }
})

module.exports = router
