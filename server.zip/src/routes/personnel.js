const express = require('express')
const { Personnel, Company } = require('../models')
const { authMiddleware } = require('../middleware/auth')

const router = express.Router()

// Get all personnel
router.get('/', authMiddleware, async (req, res) => {
  try {
    const { companyId, status } = req.query
    const where = {}
    
    if (companyId) where.companyId = companyId
    if (status) where.status = status

    const personnel = await Personnel.findAll({
      where,
      include: [
        { model: Company, as: 'company', attributes: ['id', 'name', 'code'] }
      ],
      order: [['createdAt', 'DESC']]
    })

    res.json(personnel.map(p => ({
      ...p.toJSON(),
      company: p.company?.name || ''
    })))
  } catch (error) {
    console.error('Get personnel error:', error)
    res.status(500).json({ message: 'Personeller alınırken hata oluştu' })
  }
})

// Get personnel by ID
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const person = await Personnel.findByPk(req.params.id, {
      include: [{ model: Company, as: 'company' }]
    })

    if (!person) {
      return res.status(404).json({ message: 'Personel bulunamadı' })
    }

    res.json(person)
  } catch (error) {
    console.error('Get personnel error:', error)
    res.status(500).json({ message: 'Personel alınırken hata oluştu' })
  }
})

// Create personnel
router.post('/', authMiddleware, async (req, res) => {
  try {
    const person = await Personnel.create(req.body)
    res.status(201).json(person)
  } catch (error) {
    console.error('Create personnel error:', error)
    res.status(500).json({ message: 'Personel oluşturulurken hata oluştu' })
  }
})

// Update personnel
router.put('/:id', authMiddleware, async (req, res) => {
  try {
    const person = await Personnel.findByPk(req.params.id)

    if (!person) {
      return res.status(404).json({ message: 'Personel bulunamadı' })
    }

    await person.update(req.body)
    res.json(person)
  } catch (error) {
    console.error('Update personnel error:', error)
    res.status(500).json({ message: 'Personel güncellenirken hata oluştu' })
  }
})

// Delete personnel
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const person = await Personnel.findByPk(req.params.id)

    if (!person) {
      return res.status(404).json({ message: 'Personel bulunamadı' })
    }

    await person.destroy()
    res.json({ message: 'Personel silindi' })
  } catch (error) {
    console.error('Delete personnel error:', error)
    res.status(500).json({ message: 'Personel silinirken hata oluştu' })
  }
})

module.exports = router
