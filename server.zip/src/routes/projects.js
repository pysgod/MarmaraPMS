const express = require('express')
const { Project, Company, Task, Patrol, Personnel } = require('../models')
const { authMiddleware } = require('../middleware/auth')

const router = express.Router()

// Get all projects
router.get('/', authMiddleware, async (req, res) => {
  try {
    const { companyId, status } = req.query
    const where = {}
    
    if (companyId) where.companyId = companyId
    if (status) where.status = status

    const projects = await Project.findAll({
      where,
      include: [
        { model: Company, as: 'company', attributes: ['id', 'name', 'code'] }
      ],
      order: [['createdAt', 'DESC']]
    })

    res.json(projects.map(p => ({
      ...p.toJSON(),
      company: p.company?.name || ''
    })))
  } catch (error) {
    console.error('Get projects error:', error)
    res.status(500).json({ message: 'Projeler alınırken hata oluştu' })
  }
})

// Get project by ID
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const project = await Project.findByPk(req.params.id, {
      include: [
        { model: Company, as: 'company' },
        { model: Task, as: 'tasks', include: [{ model: Personnel, as: 'assignee' }] },
        { model: Patrol, as: 'patrols', include: [{ model: Personnel, as: 'assignee' }] }
      ]
    })

    if (!project) {
      return res.status(404).json({ message: 'Proje bulunamadı' })
    }

    res.json(project)
  } catch (error) {
    console.error('Get project error:', error)
    res.status(500).json({ message: 'Proje alınırken hata oluştu' })
  }
})

// Create project
router.post('/', authMiddleware, async (req, res) => {
  try {
    const project = await Project.create(req.body)
    res.status(201).json(project)
  } catch (error) {
    console.error('Create project error:', error)
    res.status(500).json({ message: 'Proje oluşturulurken hata oluştu' })
  }
})

// Update project
router.put('/:id', authMiddleware, async (req, res) => {
  try {
    const project = await Project.findByPk(req.params.id)

    if (!project) {
      return res.status(404).json({ message: 'Proje bulunamadı' })
    }

    await project.update(req.body)
    res.json(project)
  } catch (error) {
    console.error('Update project error:', error)
    res.status(500).json({ message: 'Proje güncellenirken hata oluştu' })
  }
})

// Delete project
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const project = await Project.findByPk(req.params.id)

    if (!project) {
      return res.status(404).json({ message: 'Proje bulunamadı' })
    }

    await project.destroy()
    res.json({ message: 'Proje silindi' })
  } catch (error) {
    console.error('Delete project error:', error)
    res.status(500).json({ message: 'Proje silinirken hata oluştu' })
  }
})

module.exports = router
