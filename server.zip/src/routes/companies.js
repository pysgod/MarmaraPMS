const express = require('express')
const { Company, Project, Personnel, Patrol } = require('../models')
const { authMiddleware } = require('../middleware/auth')

const router = express.Router()

// Get all companies
router.get('/', authMiddleware, async (req, res) => {
  try {
    const companies = await Company.findAll({
      include: [
        { model: Project, as: 'projects', attributes: ['id'] },
        { model: Personnel, as: 'personnel', attributes: ['id'] }
      ],
      order: [['createdAt', 'DESC']]
    })

    const companiesWithCounts = companies.map(c => ({
      id: c.id,
      name: c.name,
      code: c.code,
      phone: c.phone,
      email: c.email,
      address: c.address,
      taxNumber: c.taxNumber,
      status: c.status,
      personnel: c.personnel.length,
      projects: c.projects.length,
      createdAt: c.createdAt
    }))

    res.json(companiesWithCounts)
  } catch (error) {
    console.error('Get companies error:', error)
    res.status(500).json({ message: 'Firmalar alınırken hata oluştu' })
  }
})

// Get company by ID
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const company = await Company.findByPk(req.params.id, {
      include: [
        { model: Project, as: 'projects' },
        { model: Personnel, as: 'personnel' },
        { model: Patrol, as: 'patrols' }
      ]
    })

    if (!company) {
      return res.status(404).json({ message: 'Firma bulunamadı' })
    }

    res.json({
      ...company.toJSON(),
      personnelCount: company.personnel.length,
      projectsCount: company.projects.length,
      patrolsCount: company.patrols.length
    })
  } catch (error) {
    console.error('Get company error:', error)
    res.status(500).json({ message: 'Firma alınırken hata oluştu' })
  }
})

// Create company
router.post('/', authMiddleware, async (req, res) => {
  try {
    const { name, code, phone, email, address, taxNumber, status } = req.body

    const existingCompany = await Company.findOne({ where: { code } })
    if (existingCompany) {
      return res.status(400).json({ message: 'Bu firma kodu zaten kullanılıyor' })
    }

    const company = await Company.create({
      name,
      code,
      phone,
      email,
      address,
      taxNumber,
      status: status || 'active'
    })

    res.status(201).json(company)
  } catch (error) {
    console.error('Create company error:', error)
    res.status(500).json({ message: 'Firma oluşturulurken hata oluştu' })
  }
})

// Update company
router.put('/:id', authMiddleware, async (req, res) => {
  try {
    const company = await Company.findByPk(req.params.id)

    if (!company) {
      return res.status(404).json({ message: 'Firma bulunamadı' })
    }

    await company.update(req.body)
    res.json(company)
  } catch (error) {
    console.error('Update company error:', error)
    res.status(500).json({ message: 'Firma güncellenirken hata oluştu' })
  }
})

// Delete company
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const company = await Company.findByPk(req.params.id)

    if (!company) {
      return res.status(404).json({ message: 'Firma bulunamadı' })
    }

    await company.destroy()
    res.json({ message: 'Firma silindi' })
  } catch (error) {
    console.error('Delete company error:', error)
    res.status(500).json({ message: 'Firma silinirken hata oluştu' })
  }
})

module.exports = router
