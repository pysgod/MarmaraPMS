const express = require('express')
const { Company, Project, Personnel, Patrol } = require('../models')
const { authMiddleware } = require('../middleware/auth')

const router = express.Router()

// Get dashboard stats
router.get('/', authMiddleware, async (req, res) => {
  try {
    const [
      totalCompanies,
      activeCompanies,
      totalProjects,
      activeProjects,
      completedProjects,
      totalPersonnel,
      activePersonnel,
      totalPatrols,
      activePatrols,
      completedPatrols,
      pendingPatrols
    ] = await Promise.all([
      Company.count(),
      Company.count({ where: { status: 'active' } }),
      Project.count(),
      Project.count({ where: { status: 'active' } }),
      Project.count({ where: { status: 'completed' } }),
      Personnel.count(),
      Personnel.count({ where: { status: 'active' } }),
      Patrol.count(),
      Patrol.count({ where: { status: 'active' } }),
      Patrol.count({ where: { status: 'completed' } }),
      Patrol.count({ where: { status: 'pending' } })
    ])

    res.json({
      totalCompanies,
      activeCompanies,
      totalProjects,
      activeProjects,
      completedProjects,
      totalPersonnel,
      activePersonnel,
      totalPatrols,
      activePatrols,
      completedPatrols,
      pendingPatrols
    })
  } catch (error) {
    console.error('Get stats error:', error)
    res.status(500).json({ message: 'İstatistikler alınırken hata oluştu' })
  }
})

module.exports = router
