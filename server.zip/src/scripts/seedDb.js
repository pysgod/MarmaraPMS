require('dotenv').config()
const { sequelize, User, Company, Project, Personnel, Patrol, Notification } = require('../models')

async function seedDatabase() {
  try {
    console.log('🔄 Veritabanına örnek veriler ekleniyor...')

    // Create admin user
    const adminUser = await User.create({
      email: 'admin@marmara.com',
      password: 'admin123',
      name: 'Admin User',
      role: 'admin',
      status: 'active'
    })
    console.log('✅ Admin kullanıcı oluşturuldu')

    // Create companies
    const companies = await Company.bulkCreate([
      { name: 'Marmara Güvenlik A.Ş.', code: 'MRG-001', phone: '+90 212 555 0001', email: 'info@marmara.com', address: 'İstanbul, Türkiye', taxNumber: '1234567890', status: 'active' },
      { name: 'Boğaziçi Koruma Ltd.', code: 'BGK-002', phone: '+90 212 555 0002', email: 'info@bogazici.com', address: 'İstanbul, Türkiye', taxNumber: '2345678901', status: 'active' },
      { name: 'Anadolu Güvenlik Hiz.', code: 'AGH-003', phone: '+90 312 555 0003', email: 'info@anadolu.com', address: 'Ankara, Türkiye', taxNumber: '3456789012', status: 'passive' },
      { name: 'İstanbul Security Inc.', code: 'ISI-004', phone: '+90 212 555 0004', email: 'info@istanbulsecurity.com', address: 'İstanbul, Türkiye', taxNumber: '4567890123', status: 'active' },
      { name: 'Ege Koruma Sistemleri', code: 'EKS-005', phone: '+90 232 555 0005', email: 'info@egekoruma.com', address: 'İzmir, Türkiye', taxNumber: '5678901234', status: 'active' },
    ])
    console.log('✅ 5 firma oluşturuldu')

    // Create projects
    const projects = await Project.bulkCreate([
      { companyId: companies[0].id, name: 'Plaza Güvenlik Projesi', category: 'Bina Güvenliği', status: 'active', progress: 75, startDate: '2024-01-01', endDate: '2024-12-31', location: 'İstanbul', manager: 'Ahmet Yılmaz' },
      { companyId: companies[1].id, name: 'AVM Devriye Sistemi', category: 'Devriye', status: 'active', progress: 45, startDate: '2024-02-01', endDate: '2024-10-31', location: 'İstanbul', manager: 'Mehmet Demir' },
      { companyId: companies[2].id, name: 'Fabrika Koruma', category: 'Endüstriyel', status: 'completed', progress: 100, startDate: '2023-06-01', endDate: '2024-01-15', location: 'Ankara', manager: 'Ayşe Kaya' },
      { companyId: companies[3].id, name: 'Otel Güvenlik Hizmeti', category: 'Konaklama', status: 'active', progress: 60, startDate: '2024-03-01', endDate: '2025-03-01', location: 'İstanbul', manager: 'Fatma Özkan' },
      { companyId: companies[4].id, name: 'Site Giriş Kontrolü', category: 'Konut', status: 'pending', progress: 20, startDate: '2024-06-01', endDate: '2024-12-31', location: 'İzmir', manager: 'Ali Çelik' },
    ])
    console.log('✅ 5 proje oluşturuldu')

    // Create personnel
    const personnel = await Personnel.bulkCreate([
      { companyId: companies[0].id, name: 'Ahmet Yılmaz', email: 'ahmet@marmara.com', phone: '+90 532 111 2233', role: 'Güvenlik Şefi', status: 'active' },
      { companyId: companies[1].id, name: 'Mehmet Demir', email: 'mehmet@bogazici.com', phone: '+90 533 222 3344', role: 'Devriye Sorumlusu', status: 'active' },
      { companyId: companies[2].id, name: 'Ayşe Kaya', email: 'ayse@anadolu.com', phone: '+90 534 333 4455', role: 'Operasyon Müdürü', status: 'active' },
      { companyId: companies[3].id, name: 'Fatma Özkan', email: 'fatma@istanbul.com', phone: '+90 535 444 5566', role: 'Güvenlik Personeli', status: 'passive' },
      { companyId: companies[4].id, name: 'Ali Çelik', email: 'ali@ege.com', phone: '+90 536 555 6677', role: 'Saha Amiri', status: 'active' },
      { companyId: companies[0].id, name: 'Mustafa Yıldız', email: 'mustafa@marmara.com', phone: '+90 537 666 7788', role: 'Güvenlik Personeli', status: 'active' },
      { companyId: companies[0].id, name: 'Zeynep Aksoy', email: 'zeynep@marmara.com', phone: '+90 538 777 8899', role: 'Güvenlik Personeli', status: 'active' },
    ])
    console.log('✅ 7 personel oluşturuldu')

    // Create patrols
    const patrols = await Patrol.bulkCreate([
      { companyId: companies[0].id, projectId: projects[0].id, personnelId: personnel[0].id, name: 'Gece Devriyesi A', location: 'Plaza Katları', timeRange: '22:00 - 06:00', status: 'active' },
      { companyId: companies[1].id, projectId: projects[1].id, personnelId: personnel[1].id, name: 'AVM Tur 1', location: 'Zemin Kat', timeRange: '10:00 - 14:00', status: 'completed' },
      { companyId: companies[2].id, projectId: projects[2].id, personnelId: personnel[2].id, name: 'Fabrika Çevre Kontrolü', location: 'Dış Alan', timeRange: '08:00 - 16:00', status: 'pending' },
      { companyId: companies[3].id, projectId: projects[3].id, personnelId: personnel[4].id, name: 'Otel Giriş Kontrolü', location: 'Lobi', timeRange: '00:00 - 08:00', status: 'active' },
    ])
    console.log('✅ 4 devriye oluşturuldu')

    // Create notifications for admin
    await Notification.bulkCreate([
      { userId: adminUser.id, title: 'Yeni proje oluşturuldu', message: 'Plaza Güvenlik Projesi başarıyla oluşturuldu.', type: 'success', read: false },
      { userId: adminUser.id, title: 'Devriye tamamlandı', message: 'AVM Tur 1 devriyesi başarıyla tamamlandı.', type: 'info', read: false },
      { userId: adminUser.id, title: 'Personel güncellemesi', message: 'Fatma Özkan pasif duruma alındı.', type: 'warning', read: true },
      { userId: adminUser.id, title: 'Sistem bakımı', message: 'Yarın 02:00-04:00 arası bakım yapılacak.', type: 'info', read: true },
    ])
    console.log('✅ 4 bildirim oluşturuldu')

    console.log('\n🎉 Veritabanı başarıyla dolduruldu!')
    console.log('\n📋 Giriş bilgileri:')
    console.log('   Email: admin@marmara.com')
    console.log('   Şifre: admin123')
    
    process.exit(0)
  } catch (error) {
    console.error('❌ Seed hatası:', error)
    process.exit(1)
  }
}

sequelize.sync({ force: true }).then(seedDatabase)
