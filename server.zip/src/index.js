require('dotenv').config()
const express = require('express')
const cors = require('cors')
const { sequelize } = require('./models')

// Routes
const authRoutes = require('./routes/auth')
const companyRoutes = require('./routes/companies')
const projectRoutes = require('./routes/projects')
const personnelRoutes = require('./routes/personnel')
const patrolRoutes = require('./routes/patrols')
const notificationRoutes = require('./routes/notifications')
const statsRoutes = require('./routes/stats')

const app = express()

// Middleware
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true
}))
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() })
})

// API Routes
app.use('/api/auth', authRoutes)
app.use('/api/companies', companyRoutes)
app.use('/api/projects', projectRoutes)
app.use('/api/personnel', personnelRoutes)
app.use('/api/patrols', patrolRoutes)
app.use('/api/notifications', notificationRoutes)
app.use('/api/stats', statsRoutes)

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).json({ message: 'Sunucu hatası', error: err.message })
})

// 404 handler
app.use((req, res) => {
  res.status(404).json({ message: 'Endpoint bulunamadı' })
})

const PORT = process.env.PORT || 3001

async function start() {
  try {
    await sequelize.authenticate()
    console.log('✅ PostgreSQL bağlantısı başarılı')
    
    // Sync database (use { force: true } only in development to reset tables)
    await sequelize.sync({ alter: true })
    console.log('✅ Veritabanı tabloları senkronize edildi')
    
    app.listen(PORT, () => {
      console.log(`🚀 Sunucu http://localhost:${PORT} adresinde çalışıyor`)
    })
  } catch (error) {
    console.error('❌ Sunucu başlatma hatası:', error)
    process.exit(1)
  }
}

start()
