const sequelize = require('../config/database')
const User = require('./User')
const Company = require('./Company')
const Project = require('./Project')
const Personnel = require('./Personnel')
const Patrol = require('./Patrol')
const Task = require('./Task')
const Notification = require('./Notification')

// Company associations
Company.hasMany(Project, { foreignKey: 'companyId', as: 'projects' })
Company.hasMany(Personnel, { foreignKey: 'companyId', as: 'personnel' })
Company.hasMany(Patrol, { foreignKey: 'companyId', as: 'patrols' })

// Project associations
Project.belongsTo(Company, { foreignKey: 'companyId', as: 'company' })
Project.hasMany(Task, { foreignKey: 'projectId', as: 'tasks' })
Project.hasMany(Patrol, { foreignKey: 'projectId', as: 'patrols' })

// Personnel associations
Personnel.belongsTo(Company, { foreignKey: 'companyId', as: 'company' })
Personnel.hasMany(Task, { foreignKey: 'assigneeId', as: 'tasks' })
Personnel.hasMany(Patrol, { foreignKey: 'personnelId', as: 'patrols' })

// Patrol associations
Patrol.belongsTo(Company, { foreignKey: 'companyId', as: 'company' })
Patrol.belongsTo(Project, { foreignKey: 'projectId', as: 'project' })
Patrol.belongsTo(Personnel, { foreignKey: 'personnelId', as: 'assignee' })

// Task associations
Task.belongsTo(Project, { foreignKey: 'projectId', as: 'project' })
Task.belongsTo(Personnel, { foreignKey: 'assigneeId', as: 'assignee' })

// Notification associations
Notification.belongsTo(User, { foreignKey: 'userId', as: 'user' })
User.hasMany(Notification, { foreignKey: 'userId', as: 'notifications' })

module.exports = {
  sequelize,
  User,
  Company,
  Project,
  Personnel,
  Patrol,
  Task,
  Notification
}
